# galpal
Galaxy classification tool -- just galaxies being palaxies

To do
- Import images
   - Consider including a line in the code to download images
- Display images
- Have a classification attached to each image